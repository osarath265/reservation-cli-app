package model;

public enum RoomType {
    Single,
    Double
}
